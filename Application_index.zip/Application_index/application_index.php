<html>
    <head>
        <title>
</title> 


    </head>
        <body>



     <?php
         $james=mysqli_connect("localhost","root","","forms");

          $firstname=mysqli_real_escape_string($james, $_POST['firstname']);
          $middlename=mysqli_real_escape_string($james, $_POST['middlename']);
          $lastname=mysqli_real_escape_string($james, $_POST['lastname']);
          $citizenship=mysqli_real_escape_string($james, $_POST['citizenship']);
          $country=mysqli_real_escape_string($james, $_POST['country']);
          $county=mysqli_real_escape_string($james, $_POST['county']);
          $passport=mysqli_real_escape_string($james, $_POST['passport']);
          $gender=mysqli_real_escape_string($james, $_POST['gender']);
          $education=mysqli_real_escape_string($james, $_POST['education']);
          $disability=mysqli_real_escape_string($james, $_POST['disability']);
          $religion=mysqli_real_escape_string($james, $_POST['Religion']);
          $postaladdress=mysqli_real_escape_string($james, $_POST['postaladdress']);
          $postalcode=mysqli_real_escape_string($james, $_POST['postalcode']);
          $town=mysqli_real_escape_string($james, $_POST['town']);
          $telephone=mysqli_real_escape_string($james, $_POST['telephone']);
          $mobileno=mysqli_real_escape_string($james, $_POST['mobileno']);
          $email=mysqli_real_escape_string($james, $_POST['email']);
          $course=mysqli_real_escape_string($james, $_POST['course']);



         $table="INSERT INTO form_data(firstname, middlename, lastname, citizenship, country, county, passport, gender, education, disability, religion, postaladdress, postalcode, town, telephone, mobileno, email,course)
            VALUES ('$firstname', '$middlename', '$lastname', '$citizenship', '$country', '$county', 'passport', 'gender', '$education', '$disability','$religion', '$postaladdress', '$postalcode', '$town', '$telephone', '$mobileno', '$email', '$course')";

            if(mysqli_query($james, $table))
            {
                echo "Data entry successful";
            }
            else
            {
                echo "Data entry not successful";
            }

            //Email
            $headers="From: Kamau James";
            $subject="Successful Form Submission";
            $message="Dear $lastname $firstname, Your application has been successfully submitted for $course. Please await the outcome in two weeks time. Yours Registrar";

            mail($email, $subject, $message, $headers);
        ?>

    </body>
    
</html>